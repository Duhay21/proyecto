from django.apps import AppConfig


class FarmaxConfig(AppConfig):
    name = 'Aplicaciones.Farmax'
